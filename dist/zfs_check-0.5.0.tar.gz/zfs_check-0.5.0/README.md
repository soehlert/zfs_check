# zfscheck

Check on the health of your ZFS pools proactively