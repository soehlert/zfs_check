# zfs_check

Check on the health of your ZFS pools proactively
